
//-----------------------------------------------------------------------
// Inicialización
//-----------------------------------------------------------------------

$("body").ready(() => {
    $("#botonMostarPares").on("click", mostrarPars);
    $("#botonLimpia").on("click", () => $('textoResultado').value(''));
});


//-----------------------------------------------------------------------
// Gestores de eventos
//-----------------------------------------------------------------------

function mostrarPares() {

    $("textoResultado").value('');
    const numero = $("numero").value();

    for(let n = 1;n <= numero;n++) {
        if(n % 2 == 0) {
            $("textoResultado").value($("textoResultado").value()+','+n);
        }
    }

}