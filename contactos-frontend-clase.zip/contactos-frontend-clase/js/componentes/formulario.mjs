// API para control y validación de formulario.
// A ver como lo enlazamos de modo que permita validar, controlar y enviar formularios.

