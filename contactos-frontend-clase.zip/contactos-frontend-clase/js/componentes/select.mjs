// Un select que se carga desde la base de datos
// Acepta un servicio como argumento y lo utiliza para cargar los datos