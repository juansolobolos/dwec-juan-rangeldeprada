//---------------------------------------------------------------
// Variables de configuración
//---------------------------------------------------------------

/**
 * Direccion del backend
 */
const URL_BASE="http://localhost:3000";

/**
 * Número de registros por página
 */
const REGISTROS_POR_PAGINA = 10;