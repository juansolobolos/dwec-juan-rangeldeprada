//---------------------------------------------------------------
// Variables de configuración
//---------------------------------------------------------------

/**
 * Direccion del backend
 */
export const URL_BASE="http://localhost:3000";

/**
 * Número de registros por página
 */
export const REGISTROS_POR_PAGINA = 10;